# OMK Crypto Investment Platform (Laravel Scaffold)

A cPanel-ready, crypto-integrated investment platform built on Laravel.

## Features

- `/login` as landing page (no home page)
- User and admin dashboards
- Install wizard at `/install`
- Role-based admin access (`/magic`)
- TailwindCSS dark-themed UI
- Ready for crypto, KYC, ticketing, and more!

## Install & Deploy

### 1. Upload Files
- Upload project files to cPanel, ideally in `public_html/omk_crypto_investment`
- Point your domain/subdomain to the `/public` folder

### 2. Composer & Node
- SSH into cPanel (or use terminal):
  ```
  composer install --no-dev
  npm install && npm run build
  ```

### 3. Permissions
- Set storage and cache permissions:
  ```
  chmod -R 775 storage bootstrap/cache
  ```

### 4. Database
- Create a MySQL/PostgreSQL DB via cPanel
- Ensure DB credentials are ready

### 5. Install Wizard
- Visit `https://yourdomain.com/install`
- Follow the steps: DB, admin account, mail, etc.
- After install, `/install` will be locked

### 6. Cron Jobs
- Set up in cPanel:
  ```
  * * * * * cd /home/youruser/omk_crypto_investment && php artisan schedule:run >> /dev/null 2>&1
  ```

### 7. SSL & Security
- Enable SSL in cPanel
- Force HTTPS in `.htaccess` if desired

### 8. Login
- Admin: `admin@tonsuimining.com` / `Successtrain2025@`

---

## Extend

- Add blockchain, KYC, ticketing, plans, etc. as per your workflow
- See `/routes/web.php` and `/app/Models/` for starting points

---

## License

[Include your license here]