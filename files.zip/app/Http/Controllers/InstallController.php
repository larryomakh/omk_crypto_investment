<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

class InstallController extends Controller
{
    public function index(Request $request)
    {
        $step = $request->get('step', 1);
        return view('install.index', compact('step'));
    }

    public function install(Request $request)
    {
        // Example: Only DB setup and admin seed for brevity
        if ($request->has('db_host')) {
            $env = File::get(base_path('.env.example'));
            $env = str_replace([
                'DB_HOST=127.0.0.1',
                'DB_DATABASE=laravel',
                'DB_USERNAME=root',
                'DB_PASSWORD=',
            ], [
                'DB_HOST=' . $request->input('db_host'),
                'DB_DATABASE=' . $request->input('db_name'),
                'DB_USERNAME=' . $request->input('db_user'),
                'DB_PASSWORD=' . $request->input('db_pass'),
            ], $env);
            File::put(base_path('.env'), $env);

            Artisan::call('config:clear');
            Artisan::call('migrate', ['--force' => true]);
            Artisan::call('db:seed', ['--class' => 'AdminSeeder', '--force' => true]);
            File::put(storage_path('installed'), 'installed');

            return view('install.finish');
        }

        return redirect()->route('install.index', ['step' => $request->input('step', 1) + 1]);
    }
}