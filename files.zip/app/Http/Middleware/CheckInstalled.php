<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckInstalled
{
    public function handle(Request $request, Closure $next)
    {
        if (file_exists(storage_path('installed')) && file_exists(base_path('.env'))) {
            return redirect('/login');
        }
        return $next($request);
    }
}