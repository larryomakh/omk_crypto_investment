<?php

namespace App\Http\Middleware;

use Closure;

class Installed
{
    public function handle($request, Closure $next)
    {
        if (!file_exists(storage_path('installed')) || !file_exists(base_path('.env'))) {
            return redirect('/install');
        }
        return $next($request);
    }
}