@extends('layouts.app')

@section('content')
<div class="py-12 max-w-5xl mx-auto">
    <h1 class="text-3xl text-purple-400 font-bold mb-8">Admin Panel</h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-gradient-to-br from-blue-800 to-purple-800 p-6 rounded-lg shadow">
            <div class="text-gray-100">Users</div>
            <div class="text-2xl font-bold text-white">0</div>
        </div>
        <div class="bg-gradient-to-br from-gray-800 to-blue-800 p-6 rounded-lg shadow">
            <div class="text-gray-100">Deposits</div>
            <div class="text-2xl font-bold text-white">0</div>
        </div>
        <div class="bg-gradient-to-br from-purple-900 to-gray-900 p-6 rounded-lg shadow">
            <div class="text-gray-100">Withdrawals</div>
            <div class="text-2xl font-bold text-white">0</div>
        </div>
    </div>
</div>
@endsection