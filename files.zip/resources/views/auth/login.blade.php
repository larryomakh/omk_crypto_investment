@extends('layouts.app')

@section('content')
<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-gray-900 to-blue-900">
    <form method="POST" action="{{ route('login') }}" class="bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-sm">
        @csrf
        <h2 class="text-2xl mb-6 text-purple-400 font-bold">Login</h2>
        <div class="mb-4">
            <label class="block text-gray-200">Email</label>
            <input type="email" name="email" class="input w-full" required autofocus>
        </div>
        <div class="mb-4">
            <label class="block text-gray-200">Password</label>
            <input type="password" name="password" class="input w-full" required>
        </div>
        <button class="btn btn-primary w-full">Login</button>
    </form>
</div>
@endsection