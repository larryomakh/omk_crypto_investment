@extends('layouts.app')

@section('content')
<div class="w-full max-w-lg mx-auto py-12">
    <div class="bg-gray-800 rounded-lg shadow-lg p-8 text-center">
        <h2 class="text-2xl font-bold text-green-400 mb-6">Installation Complete!</h2>
        <p class="mb-8 text-gray-100">Your OMK Crypto Investment platform is now installed and ready.</p>
        <a href="/login" class="btn btn-primary">Go to Login</a>
    </div>
</div>
@endsection