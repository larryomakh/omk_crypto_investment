@extends('layouts.app')

@section('content')
<div class="w-full max-w-lg mx-auto py-12">
    <div class="bg-gray-800 rounded-lg shadow-lg p-8">
        <h2 class="text-2xl font-bold text-purple-400 mb-6">OMK Crypto Investment Install Wizard</h2>
        @if(request('step') == 1)
            <form method="POST" action="{{ route('install.run') }}">
                @csrf
                <p class="mb-4 text-gray-100">Welcome! Let's set up your app.</p>
                <button class="btn btn-primary" name="step" value="2">Begin</button>
            </form>
        @elseif(request('step') == 2)
            <form method="POST" action="{{ route('install.run') }}">
                @csrf
                <p class="mb-2 text-gray-100">Accept license and terms.</p>
                <textarea class="w-full h-24 mb-2" readonly>License terms go here...</textarea>
                <label class="inline-flex items-center">
                  <input type="checkbox" name="accept" required>
                  <span class="ml-2 text-gray-200">I accept the terms</span>
                </label>
                <button class="btn btn-primary mt-4" name="step" value="3">Next</button>
            </form>
        @elseif(request('step') == 3)
            <form method="POST" action="{{ route('install.run') }}">
                @csrf
                <h3 class="mb-2 text-gray-100">Database Setup</h3>
                <input class="input mb-2" name="db_host" placeholder="DB Host" required>
                <input class="input mb-2" name="db_name" placeholder="DB Name" required>
                <input class="input mb-2" name="db_user" placeholder="DB User" required>
                <input class="input mb-2" name="db_pass" placeholder="DB Password">
                <button class="btn btn-primary mt-4">Next</button>
            </form>
        @else
            <div class="text-green-400 text-xl">Installation Complete!</div>
            <a href="/login" class="btn btn-secondary mt-4">Go to Login</a>
        @endif
    </div>
</div>
@endsection