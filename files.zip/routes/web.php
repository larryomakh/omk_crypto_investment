<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Admin\AdminDashboardController;
use Illuminate\Support\Facades\Auth;

// Install Wizard (only when not installed)
Route::middleware(['web', \App\Http\Middleware\CheckInstalled::class])->group(function () {
    Route::get('/install', [InstallController::class, 'index'])->name('install.index');
    Route::post('/install', [InstallController::class, 'install'])->name('install.run');
});

// Auth routes (registration disabled)
Auth::routes([
    'register' => false,
    'reset' => true,
    'verify' => false,
]);

// Redirect root to login
Route::redirect('/', '/login');

// User dashboard
Route::middleware(['auth', 'installed'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

// Admin panel (/magic)
Route::middleware(['auth', 'installed', 'admin'])->prefix('magic')->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
});