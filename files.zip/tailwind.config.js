module.exports = {
  content: [
    "./resources/views/**/*.blade.php",
    "./resources/js/**/*.js",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        purple: {
          400: "#a78bfa",
          800: "#5b21b6",
          900: "#312e81",
        },
        blue: {
          400: "#60a5fa",
          800: "#1e3a8a",
        },
        gray: {
          800: "#1f2937",
          900: "#111827",
        },
      },
    },
  },
  plugins: [],
};